const form = document.getElementById("form")

const nameInput = document.getElementById("name")
const emailInput = document.getElementById("email")
const phoneInput = document.getElementById("phone")
const passwordInput = document.getElementById("password")

const nameError = document.getElementById("nameError")
const emailError = document.getElementById("emailError")
const phoneError = document.getElementById("phoneError")
const passwordError = document.getElementById("passwordError")

const strengthBar = document.getElementById("strengthBar")
const togglePassword = document.getElementById("togglePassword")


/* Name validation */

nameInput.addEventListener("input", () => {

if(nameInput.value.length < 3){
nameError.innerText = "Name must be at least 3 characters"
}else{
nameError.innerText = ""
}

})


/* Email validation */

emailInput.addEventListener("input", () => {

const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/

if(!emailPattern.test(emailInput.value)){
emailError.innerText = "Enter valid email"
}else{
emailError.innerText = ""
}

})


/* Phone validation */

phoneInput.addEventListener("input", () => {

const phonePattern = /^[0-9]{10}$/

if(!phonePattern.test(phoneInput.value)){
phoneError.innerText = "Enter 10 digit phone number"
}else{
phoneError.innerText = ""
}

})


/* Password strength */

passwordInput.addEventListener("input", () => {

let value = passwordInput.value
let strength = 0

if(value.length >= 6) strength++
if(/[A-Z]/.test(value)) strength++
if(/[0-9]/.test(value)) strength++
if(/[^A-Za-z0-9]/.test(value)) strength++

if(strength == 1){
strengthBar.style.width = "25%"
strengthBar.style.background = "red"
}

else if(strength == 2){
strengthBar.style.width = "50%"
strengthBar.style.background = "orange"
}

else if(strength == 3){
strengthBar.style.width = "75%"
strengthBar.style.background = "yellowgreen"
}

else if(strength == 4){
strengthBar.style.width = "100%"
strengthBar.style.background = "green"
}

})


/* Show hide password */

togglePassword.addEventListener("click", () => {

if(passwordInput.type === "password"){
passwordInput.type = "text"
togglePassword.innerText = "Hide"
}
else{
passwordInput.type = "password"
togglePassword.innerText = "Show"
}

})


/* Form submit */

form.addEventListener("submit", function(e){

e.preventDefault()

const userData = {
name: nameInput.value,
email: emailInput.value,
phone: phoneInput.value,
password: passwordInput.value
}

let submissions = JSON.parse(localStorage.getItem("submissions")) || []

submissions.push(userData)

localStorage.setItem("submissions", JSON.stringify(submissions))

alert("Registration Successful!")

form.reset()
strengthBar.style.width="0%"

})